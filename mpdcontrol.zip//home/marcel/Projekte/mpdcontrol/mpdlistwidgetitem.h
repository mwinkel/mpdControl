#ifndef MPDLISTWIDGETITEM_H
#define MPDLISTWIDGETITEM_H

#include <QListWidgetItem>

class MpdListWidgetItem : public QListWidgetItem
{
    Q_OBJECT

    public:
        MpdListWidgetItem();
        MpdListWidgetItem(QString title, int songid, int position);
        ~MpdListWidgetItem();

    private:
        QString title;
        int songid;
        int position;
};

#endif // MPDLISTWIDGETITEM_H
