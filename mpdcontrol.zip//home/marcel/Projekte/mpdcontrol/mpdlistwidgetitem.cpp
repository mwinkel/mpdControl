#include "mpdlistwidgetitem.h"

MpdListWidgetItem::MpdListWidgetItem()
{
}

MpdListWidgetItem::MpdListWidgetItem(QString title, int songid, int position)
{
    this->title = title;
    this->songid = songid;
    this->position = position;
}

MpdListWidgetItem::~MpdListWidgetItem(){}
